#include <stdio.h>


void test(int a, int b, int c, int d, int e, int f)
{

    printf("%d %d %d %d %d %d\n", a, b, c, d, e, f);

}
