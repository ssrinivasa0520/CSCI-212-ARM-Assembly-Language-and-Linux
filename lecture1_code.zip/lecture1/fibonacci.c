
// This program will ask the user for the nth fibonacci number
// It will compute and output the nth Fibonacci number

#include <stdio.h>

int getinput();
int compute_fib(int n);

int main()
{
    int nth;
    int nfib;

    nth = getinput();

    nfib = compute_fib(nth);

    printf("The %d Fibonacci number is %d\n", nth, nfib);

}


int getinput()
{
    int n;

    printf("Enter the nth Fibonacci: ");
    scanf("%d", &n);
    return n;
}

int compute_fib(int n)
{

    if (n == 1 || n == 2)
        return 1;

    int i, a, b;

    a = 1;
    b = 1;

    for (i = 3; i <= n; i++)
    {
        b = a + b;
        a = b - a;
        // c = a+b
        // a = b
        // b = c
    }

    return b;

}