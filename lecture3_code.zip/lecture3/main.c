
#include <stdio.h>

void get_inp(int *, int *);

int main()
{
    int n, m;
    int sum;

    get_inp(&n, &m);

    sum = n + m;

    printf("Sum = %d\n", sum);

    return 0;


}