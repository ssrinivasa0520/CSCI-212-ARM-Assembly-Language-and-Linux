#include <stdio.h>

void get_inp(int *n, int *m)
{
    printf("Enter two numbers: ");
    scanf("%d %d", n, m);
}