#include <stdio.h>
#include <stdlib.h>
#include "gofish.h"

void print_array(int* array, int n) {
	printf("Size:- %d\n", n);
	for(int i = 0; i < n; i++)
		printf("%d ", array[i]);
	printf("\n");
}
