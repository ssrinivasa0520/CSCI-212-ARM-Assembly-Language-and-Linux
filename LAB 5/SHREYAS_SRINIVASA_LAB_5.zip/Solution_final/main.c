#include <stdlib.h>
#include <stdio.h>
#include "gofish.h"

int main() {
	int p_books = 0;
	int c_books = 0;
	int *books;
	
	int stock[54];
	
	int p_hand[13] = {0};
	int c_hand[13] = {0};
	int *hand;
	
	int turn = random_no(2);
	int booked = 0;
	int reply, req_card, drawn_card;
	
	deal(stock, p_hand, c_hand);
	int st_size = 38;
	
	//~ print_array(p_hand, 13);
	//~ print_array(c_hand, 13);
	//~ print_array(stock, st_size);
	
	
	logh("START GAME\n");
	
	while(1) {
		
		//~ print_array(p_hand, 13);
		//~ print_array(c_hand, 13);
		//~ print_array(stock, st_size);
		
		if(turn == 0) {
			hand = p_hand;
			books = &p_books;
			logh("PLAYER'S TURN\n");
		} else {
			hand = c_hand;
			books = &c_books;
			logh("COMPUTERS'S TURN\n");
		}
		
		if(!check_cards(hand)) {
			drawn_card = draw(stock, &st_size, turn, -1);
			if(drawn_card != -1) {
				booked = lay_down(hand, drawn_card, books, turn);
				if(booked)
					continue;
			}
			else {
				logh("GAME OVER\n");
				// print_array(p_hand, 13);
				// print_array(c_hand, 13);
				// print_array(stock, st_size);
				winner(p_books, c_books);
				break;
			}
		}
		booked = init_lay_down(hand, books, turn);
		if(booked)
			continue;
		req_card = decide_card(p_hand, c_hand, turn);
		reply = ask(p_hand, c_hand, req_card, turn);
		if(reply != -1) {
			booked = lay_down(hand, req_card, books, turn);
		} else {
			drawn_card = draw(stock, &st_size, turn, req_card);
			booked = lay_down(hand, drawn_card, books, turn);
		}
		if(req_card == reply || req_card == drawn_card || booked)
			turn = turn;
		else
			turn = !turn;
	}
	return 0;
}
