#ifndef GOFISH_H_   
#define GOFISH_H_

void print(int*, int);
void deal(int*, int*, int*);
int check_cards(int*);
int draw(int*, int*, int, int);
int decide_card(int*, int*, int);
int ask(int*, int*, int, int);
int lay_down(int*, int, int*, int);
int init_lay_down(int*, int*, int);
int random_no(int);
char* encode(int);
void logp(char*, int, int);
void logh(char*);
void print_array(int*, int);
void winner(int, int);
#endif
